// Qala RP minimal multiplayer WebSocket server
// Node.js 18+ required. Install dependency with: npm install ws
const WebSocket = require('ws');
const wss = new WebSocket.Server({ port: 8080 });
const players = new Map();
function sendState(){const list=[...players.entries()].map(([id,p])=>({id,...p}));for(const [id,ws] of clients){if(ws.readyState===WebSocket.OPEN)ws.send(JSON.stringify({type:'state',id,players:list}));}}
const clients=new Map();let nextId=1;
wss.on('connection',ws=>{const id='p'+nextId++;clients.set(id,ws);players.set(id,{x:0,z:0,rot:0});ws.on('message',raw=>{try{const d=JSON.parse(raw.toString());if(d.type==='move'){const p=players.get(id);if(p){p.x=Number(d.x)||0;p.z=Number(d.z)||0;p.rot=Number(d.rot)||0}}}catch{}});ws.on('close',()=>{clients.delete(id);players.delete(id);sendState()});sendState()});
setInterval(sendState,100);console.log('Qala RP server listening on ws://0.0.0.0:8080');
