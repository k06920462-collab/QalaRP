QALA RP Android wrapper project

This is an Android Studio project, NOT a compiled APK. The game HTML is bundled in app/src/main/assets/index.html.
The game currently loads Three.js from a CDN, so internet is required.

Build APK:
1. Install Android Studio on a computer.
2. Open this folder as a project.
3. Let Gradle sync finish (internet required).
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. When done, click 'locate' to find app-debug.apk.

This wrapper only packages the existing prototype. It does not turn the concept screenshot into a finished game, and online multiplayer still needs a publicly hosted server configured in the game.
